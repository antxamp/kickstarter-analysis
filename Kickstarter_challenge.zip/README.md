# Kickstarting with Excel

## Overview of Project
- This project displays an analysis on different theater fundraising goals in conjunction to  outcomes associated with its launch dates.

### Purpose
-The purpose of the analysis is to show trends associated with the success or failure of theater fundraising.
## Analysis and Challenges
-With the data provided from the kickstarter spreadsheet my analysis on when fundraising is more likely to be successul is based on orgazining the data and being able to filter out the information needed. There were't any challenges I encountered but the challenges that could be encountered are missing a comma while typing out functions in cells that will throw errors at you. 
### Analysis of Outcomes Based on Launch Date
-Upon my analysis, 61% is the median for success through the year. 
### Analysis of Outcomes Based on Goals
-Keeping your fundraising goals below $4999 would yield a slightly better percentage for success.  
### Challenges and Difficulties Encountered
-None
## Results
 - With all the data avaiable there are numerous amounts of outcomes for various questions. 
- What are two conclusions you can draw about the Outcomes based on Launch Date?
    -The first conclusion I can draw about the outcomes based on launch date are that there are a high number of successful launches the the months of may and june. The second being that although the number of successful theaters in those months are high, if you look at the percentages of sucessful theaters month to month they are quite similar.
- What can you conclude about the Outcomes based on Goals?
 - Trying to fundraise with a goal of under $4999 yields better results for success.
- What are some limitations of this dataset?
  -The data is set from 2009 to 2017 and could reflect different numbers by present day.
- What are some other possible tables and/or graphs that we could create?
 - We could create a table on successful outcome of food trucks based on launch dates and goals. Similar to what we have done with theaters to see why so many foodtrucks failed using the same type of charts and tables we've created for this project.